<div class="social-wrap">
                        <ul class="socialicons">
                                <?php
                                if ( of_get_option('gg_fb') ) {
                                ?> <li> <a href="<?php echo of_get_option('gg_fb'); ?>" target="_blank" class="fb" > <i class="fa fa-facebook"></i> </a> </li>                        
                                <?php }
        
                                if ( of_get_option('gg_twitter') ) {
                                ?> <li> <a href="<?php echo of_get_option('gg_twitter'); ?>" target="_blank" class="twitter" > <i class="fa fa-twitter"></i> </a> </li>                        
                                <?php }
                                
                                if ( of_get_option('gg_googleplus') ) {
                                ?> <li> <a href="<?php echo of_get_option('gg_googleplus'); ?>" target="_blank" class="googleplus" > <i class="fa fa-google-plus"></i> </a> </li>                        
                                <?php }                                 
                                
                                if ( of_get_option('gg_dribbble') ) {
                                ?> <li> <a href="<?php echo of_get_option('gg_dribbble'); ?>" target="_blank" class="dribbble" > <i class="fa fa-dribbble"></i> </a> </li>                        
                                <?php }                                        

                                if ( of_get_option('gg_behance') ) {
                                ?> <li> <a href="<?php echo of_get_option('gg_behance'); ?>" target="_blank" class="behance" > <i class="fa fa-behance"></i> </a> </li>                        
                                <?php }   
                                
                                if ( of_get_option('gg_instagram') ) {
                                ?> <li> <a href="<?php echo of_get_option('gg_instagram'); ?>" target="_blank" class="instagram" > <i class="fa fa-instagram"></i> </a> </li>                        
                                <?php }                                

                                if ( of_get_option('gg_spotify') ) {
                                ?> <li> <a href="<?php echo of_get_option('gg_spotify'); ?>" target="_blank" class="spotify" > <i class="fa fa-spotify"></i> </a> </li>                        
                                <?php }
                                
                                if ( of_get_option('gg_youtube') ) {
                                ?> <li> <a href="<?php echo of_get_option('gg_youtube'); ?>" target="_blank" class="youtube" > <i class="fa fa-youtube"></i> </a> </li>                        
                                <?php }
                                
                                if ( of_get_option('gg_vimeo') ) {
                                ?> <li> <a href="<?php echo of_get_option('gg_vimeo'); ?>" target="_blank" class="vimeo" > <i class="fa fa-vimeo-square"></i> </a> </li>                        
                                <?php }                                

                                if ( of_get_option('gg_vine') ) {
                                ?> <li> <a href="<?php echo of_get_option('gg_vine'); ?>" target="_blank" class="vine" > <i class="fa fa-vine"></i> </a> </li>                        
                                <?php }  
 
                                if ( of_get_option('gg_soundcloud') ) {
                                ?> <li> <a href="<?php echo of_get_option('gg_soundcloud'); ?>" target="_blank" class="soundcloud" > <i class="fa fa-soundcloud"></i> </a> </li>                        
                                <?php }  
                                                               
                                if ( of_get_option('gg_github') ) {
                                ?> <li> <a href="<?php echo of_get_option('gg_github'); ?>" target="_blank" class="github" > <i class="fa fa-github"></i> </a> </li>                        
                                <?php }

                                if ( of_get_option('gg_stackoverflow') ) {
                                ?> <li> <a href="<?php echo of_get_option('gg_stackoverflow'); ?>" target="_blank" class="stackoverflow" > <i class="fa fa-stack-overflow"></i> </a> </li>                        
                                <?php }
                                
                                if ( of_get_option('gg_pinterest') ) {
                                ?> <li> <a href="<?php echo of_get_option('gg_pinterest'); ?>" target="_blank" class="pinterest" > <i class="fa fa-pinterest"></i> </a> </li>                        
                                <?php }                                

                                if ( of_get_option('gg_flickr') ) {
                                ?> <li> <a href="<?php echo of_get_option('gg_flickr'); ?>" target="_blank" class="flickr" > <i class="fa fa-flickr"></i> </a> </li>                        
                                <?php }

                                if ( of_get_option('gg_deviantart') ) {
                                ?> <li> <a href="<?php echo of_get_option('gg_deviantart'); ?>" target="_blank" class="deviantart" > <i class="fa fa-deviantart"></i> </a> </li>                        
                                <?php }

                                if ( of_get_option('gg_linkedin') ) {
                                ?> <li> <a href="<?php echo of_get_option('gg_linkedin'); ?>" target="_blank" class="linkedin" > <i class="fa fa-linkedin"></i> </a> </li>                        
                                <?php }
                                
                                if ( of_get_option('gg_skype') ) {
                                ?> <li> <a href="<?php echo of_get_option('gg_skype'); ?>" target="_blank" class="skype" > <i class="fa fa-skype"></i> </a> </li>                        
                                <?php }                                
                                
                                if ( of_get_option('gg_tumblr') ) {
                                ?> <li> <a href="<?php echo of_get_option('gg_tumblr'); ?>" target="_blank" class="tumblr" > <i class="fa fa-tumblr"></i> </a> </li>                        
                                <?php }                                
                                
                                if ( of_get_option('gg_xing') ) {
                                ?> <li> <a href="<?php echo of_get_option('gg_xing'); ?>" target="_blank" class="xing" > <i class="fa fa-xing"></i> </a> </li>                        
                                <?php }     

                                if ( of_get_option('gg_500px') ) {
                                ?> <li> <a href="<?php echo of_get_option('gg_500px'); ?>" target="_blank" class="500px" > <i class="fa fa-500px"></i> </a> </li>                        
                                <?php }                                                            

                                if ( of_get_option('gg_houzz') ) {
                                ?> <li> <a href="<?php echo of_get_option('gg_houzz'); ?>" target="_blank" class="houzz" > <i class="fa fa-houzz"></i> </a> </li>                        
                                <?php }   

                                if ( of_get_option('gg_tripadvisor') ) {
                                ?> <li> <a href="<?php echo of_get_option('gg_tripadvisor'); ?>" target="_blank" class="tripadvisor" > <i class="fa fa-tripadvisor"></i> </a> </li>                        
                                <?php }  

                                if ( of_get_option('gg_amazon') ) {
                                ?> <li> <a href="<?php echo of_get_option('gg_amazon'); ?>" target="_blank" class="amazon" > <i class="fa fa-amazon"></i> </a> </li>                        
                                <?php } 

                                ?>
                        </ul>
</div><!-- .social-->