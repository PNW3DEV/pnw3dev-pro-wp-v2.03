<div class="clients-wrap">
        
        <ul class="clientlogos">
                
                <?php
                
                if ( of_get_option('gg_client1') && of_get_option('gg_client1url') ) {
                ?> <li> <a href="<?php echo of_get_option('gg_client1url'); ?>" target="_blank" > <img src="<?php echo of_get_option('gg_client1'); ?>" alt=""> </a> </li>                        
                <?php } elseif ( of_get_option('gg_client1') ) {
                ?> <li>  <img src="<?php echo of_get_option('gg_client1'); ?>" alt=""> </li>                        
                <?php }
                
                if ( of_get_option('gg_client2') && of_get_option('gg_client2url') ) {
                ?> <li> <a href="<?php echo of_get_option('gg_client2url'); ?>" target="_blank" > <img src="<?php echo of_get_option('gg_client2'); ?>" alt=""> </a> </li>                        
                <?php } elseif ( of_get_option('gg_client2') ) {
                ?> <li>  <img src="<?php echo of_get_option('gg_client2'); ?>" alt=""> </li>                        
                <?php }                
                
                if ( of_get_option('gg_client3') && of_get_option('gg_client3url') ) {
                ?> <li> <a href="<?php echo of_get_option('gg_client3url'); ?>" target="_blank" > <img src="<?php echo of_get_option('gg_client3'); ?>" alt=""> </a> </li>                        
                <?php } elseif ( of_get_option('gg_client3') ) {
                ?> <li>  <img src="<?php echo of_get_option('gg_client3'); ?>" alt=""> </li>                        
                <?php }                
                
                if ( of_get_option('gg_client4') && of_get_option('gg_client4url') ) {
                ?> <li> <a href="<?php echo of_get_option('gg_client4url'); ?>" target="_blank" > <img src="<?php echo of_get_option('gg_client4'); ?>" alt=""> </a> </li>                        
                <?php } elseif ( of_get_option('gg_client4') ) {
                ?> <li>  <img src="<?php echo of_get_option('gg_client4'); ?>" alt=""> </li>                        
                <?php }                
                
                if ( of_get_option('gg_client5') && of_get_option('gg_client5url') ) {
                ?> <li> <a href="<?php echo of_get_option('gg_client5url'); ?>" target="_blank" > <img src="<?php echo of_get_option('gg_client5'); ?>" alt=""> </a> </li>                        
                <?php } elseif ( of_get_option('gg_client5') ) {
                ?> <li>  <img src="<?php echo of_get_option('gg_client5'); ?>" alt=""> </li>                        
                <?php }                
                
                if ( of_get_option('gg_client6') && of_get_option('gg_client6url') ) {
                ?> <li> <a href="<?php echo of_get_option('gg_client6url'); ?>" target="_blank" > <img src="<?php echo of_get_option('gg_client6'); ?>" alt=""> </a> </li>                        
                <?php } elseif ( of_get_option('gg_client6') ) {
                ?> <li>  <img src="<?php echo of_get_option('gg_client6'); ?>" alt=""> </li>                        
                <?php }                
                
                if ( of_get_option('gg_client7') && of_get_option('gg_client7url') ) {
                ?> <li> <a href="<?php echo of_get_option('gg_client7url'); ?>" target="_blank" > <img src="<?php echo of_get_option('gg_client7'); ?>" alt=""> </a> </li>                        
                <?php } elseif ( of_get_option('gg_client7') ) {
                ?> <li>  <img src="<?php echo of_get_option('gg_client7'); ?>" alt=""> </li>                        
                <?php }                
                
                if ( of_get_option('gg_client8') && of_get_option('gg_client8url') ) {
                ?> <li> <a href="<?php echo of_get_option('gg_client8url'); ?>" target="_blank" > <img src="<?php echo of_get_option('gg_client8'); ?>" alt=""> </a> </li>                        
                <?php } elseif ( of_get_option('gg_client8') ) {
                ?> <li>  <img src="<?php echo of_get_option('gg_client8'); ?>" alt=""> </li>                        
                <?php }                
                
                if ( of_get_option('gg_client9') && of_get_option('gg_client9url') ) {
                ?> <li> <a href="<?php echo of_get_option('gg_client9url'); ?>" target="_blank" > <img src="<?php echo of_get_option('gg_client9'); ?>" alt=""> </a> </li>                        
                <?php } elseif ( of_get_option('gg_client9') ) {
                ?> <li>  <img src="<?php echo of_get_option('gg_client9'); ?>" alt=""> </li>                        
                <?php }                
                
                if ( of_get_option('gg_client10') && of_get_option('gg_client10url') ) {
                ?> <li> <a href="<?php echo of_get_option('gg_client10url'); ?>" target="_blank" > <img src="<?php echo of_get_option('gg_client10'); ?>" alt=""> </a> </li>                        
                <?php } elseif ( of_get_option('gg_client10') ) {
                ?> <li>  <img src="<?php echo of_get_option('gg_client10'); ?>" alt=""> </li>                        
                <?php }                
                
                if ( of_get_option('gg_client11') && of_get_option('gg_client11url') ) {
                ?> <li> <a href="<?php echo of_get_option('gg_client11url'); ?>" target="_blank" > <img src="<?php echo of_get_option('gg_client11'); ?>" alt=""> </a> </li>                        
                <?php } elseif ( of_get_option('gg_client11') ) {
                ?> <li>  <img src="<?php echo of_get_option('gg_client11'); ?>" alt=""> </li>                        
                <?php }                
                
                if ( of_get_option('gg_client12') && of_get_option('gg_client12url') ) {
                ?> <li> <a href="<?php echo of_get_option('gg_client12url'); ?>" target="_blank" > <img src="<?php echo of_get_option('gg_client12'); ?>" alt=""> </a> </li>                        
                <?php } elseif ( of_get_option('gg_client12') ) {
                ?> <li>  <img src="<?php echo of_get_option('gg_client12'); ?>" alt=""> </li>                        
                <?php }                
                
                if ( of_get_option('gg_client13') && of_get_option('gg_client13url') ) {
                ?> <li> <a href="<?php echo of_get_option('gg_client13url'); ?>" target="_blank" > <img src="<?php echo of_get_option('gg_client13'); ?>" alt=""> </a> </li>                        
                <?php } elseif ( of_get_option('gg_client13') ) {
                ?> <li>  <img src="<?php echo of_get_option('gg_client13'); ?>" alt=""> </li>                        
                <?php }                
                
                if ( of_get_option('gg_client14') && of_get_option('gg_client14url') ) {
                ?> <li> <a href="<?php echo of_get_option('gg_client14url'); ?>" target="_blank" > <img src="<?php echo of_get_option('gg_client14'); ?>" alt=""> </a> </li>                        
                <?php } elseif ( of_get_option('gg_client14') ) {
                ?> <li>  <img src="<?php echo of_get_option('gg_client14'); ?>" alt=""> </li>                        
                <?php }                
                
                if ( of_get_option('gg_client15') && of_get_option('gg_client15url') ) {
                ?> <li> <a href="<?php echo of_get_option('gg_client15url'); ?>" target="_blank" > <img src="<?php echo of_get_option('gg_client15'); ?>" alt=""> </a> </li>                        
                <?php } elseif ( of_get_option('gg_client15') ) {
                ?> <li>  <img src="<?php echo of_get_option('gg_client15'); ?>" alt=""> </li>                        
                <?php }                  

                if ( of_get_option('gg_client16') && of_get_option('gg_client16url') ) {
                ?> <li> <a href="<?php echo of_get_option('gg_client16url'); ?>" target="_blank" > <img src="<?php echo of_get_option('gg_client16'); ?>" alt=""> </a> </li>                        
                <?php } elseif ( of_get_option('gg_client16') ) {
                ?> <li>  <img src="<?php echo of_get_option('gg_client16'); ?>" alt=""> </li>                        
                <?php }  

                if ( of_get_option('gg_client17') && of_get_option('gg_client17url') ) {
                ?> <li> <a href="<?php echo of_get_option('gg_client17url'); ?>" target="_blank" > <img src="<?php echo of_get_option('gg_client17'); ?>" alt=""> </a> </li>                        
                <?php } elseif ( of_get_option('gg_client17') ) {
                ?> <li>  <img src="<?php echo of_get_option('gg_client17'); ?>" alt=""> </li>                        
                <?php }  

                if ( of_get_option('gg_client18') && of_get_option('gg_client18url') ) {
                ?> <li> <a href="<?php echo of_get_option('gg_client18url'); ?>" target="_blank" > <img src="<?php echo of_get_option('gg_client18'); ?>" alt=""> </a> </li>                        
                <?php } elseif ( of_get_option('gg_client18') ) {
                ?> <li>  <img src="<?php echo of_get_option('gg_client18'); ?>" alt=""> </li>                        
                <?php }  

                if ( of_get_option('gg_client19') && of_get_option('gg_client19url') ) {
                ?> <li> <a href="<?php echo of_get_option('gg_client19url'); ?>" target="_blank" > <img src="<?php echo of_get_option('gg_client19'); ?>" alt=""> </a> </li>                        
                <?php } elseif ( of_get_option('gg_client19') ) {
                ?> <li>  <img src="<?php echo of_get_option('gg_client19'); ?>" alt=""> </li>                        
                <?php }  

                if ( of_get_option('gg_client20') && of_get_option('gg_client20url') ) {
                ?> <li> <a href="<?php echo of_get_option('gg_client20url'); ?>" target="_blank" > <img src="<?php echo of_get_option('gg_client20'); ?>" alt=""> </a> </li>                        
                <?php } elseif ( of_get_option('gg_client20') ) {
                ?> <li>  <img src="<?php echo of_get_option('gg_client20'); ?>" alt=""> </li>                        
                <?php }  

                
                ?>
        </ul>
        
</div><!-- .client-wrap-->