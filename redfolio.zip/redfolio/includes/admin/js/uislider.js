        <!-- uislider-->
        <script type="text/javascript">
                 jQuery.noConflict();
           (function(jQuery) {

				jQuery('#uislider').slider({
					range: true,
					values: [17, 67]
				});
            })(jQuery);
        </script>
